CYUTSUD fullscreen visual demo (Windows 10/11)

Password: 228
Emergency exit: Ctrl + Shift + Q

This is a harmless visual simulation only. It does not encrypt, delete, modify,
or upload files. It does not disable Ctrl+Alt+Delete, Task Manager, or Windows
security controls. It is borderless, full-screen, and topmost while running.

Build without installing tools on your PC:
1. Upload the contents of this folder to a GitHub repository.
2. Open Actions -> Build Windows EXE -> Run workflow.
3. Download the Cyutsudd-Fullscreen-Demo artifact after the workflow succeeds.
